#!/home/user123/Desktop/s2pro3/ib_ven/bin/python3
import logging
from ib_insync import IB
import time
import random
sleep_time = random.randint(0, 80)
time.sleep(sleep_time)
logging.basicConfig(level=logging.ERROR)

def main():
    ib = IB()
    try:
        ib.connect('127.0.0.1', 7494, clientId= 1004)
        account_info = ib.accountSummary()
        account_number = account_info[0].account
        print(f" Xian's API connected ")
    except Exception as e:
        print("Xian's API disconnected failed, please restart your IBKR account")
        print(f"Error: {e}")
    finally:
        ib.disconnect()

if __name__ == '__main__':
    main()