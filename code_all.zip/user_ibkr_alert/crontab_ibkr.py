0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr90.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr90.py >> /home/user7496/Desktop/s2pro3/output_ibkr90.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr90.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr90.py >> /home/user7496/Desktop/s2pro3/output_ibkr90.log 2>&1

0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr91.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr91.py >> /home/user7496/Desktop/s2pro3/output_ibkr91.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr91.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr91.py >> /home/user7496/Desktop/s2pro3/output_ibkr91.log 2>&1

0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr92.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr92.py >> /home/user7496/Desktop/s2pro3/output_ibkr92.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr92.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr92.py >> /home/user7496/Desktop/s2pro3/output_ibkr92.log 2>&1

0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr93.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr93.py >> /home/user7496/Desktop/s2pro3/output_ibkr93.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr93.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr93.py >> /home/user7496/Desktop/s2pro3/output_ibkr93.log 2>&1

0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr94.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr94.py >> /home/user7496/Desktop/s2pro3/output_ibkr94.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr94.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr94.py >> /home/user7496/Desktop/s2pro3/output_ibkr94.log 2>&1

0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr95.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr95.py >> /home/user7496/Desktop/s2pro3/output_ibkr95.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr95.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr95.py >> /home/user7496/Desktop/s2pro3/output_ibkr95.log 2>&1

0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr96.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr96.py >> /home/user7496/Desktop/s2pro3/output_ibkr96.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr96.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr96.py >> /home/user7496/Desktop/s2pro3/output_ibkr96.log 2>&1

0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr97.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr97.py >> /home/user7496/Desktop/s2pro3/output_ibkr97.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr97.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr97.py >> /home/user7496/Desktop/s2pro3/output_ibkr97.log 2>&1


0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr98.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr98.py >> /home/user7496/Desktop/s2pro3/output_ibkr98.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr98.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr98.py >> /home/user7496/Desktop/s2pro3/output_ibkr98.log 2>&1

0,26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr99.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr99.py >> /home/user7496/Desktop/s2pro3/output_ibkr99.log 2>&1
30,56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr99.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr99.py >> /home/user7496/Desktop/s2pro3/output_ibkr99.log 2>&1











