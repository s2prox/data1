#!/home/user7496/Desktop/s2pro3/ib_ven/bin/python3

import asyncio
import datetime as dt
import math
import ib_insync as ibi
import numpy as np
import pandas as pd
import yfinance as yf
from zoneinfo import ZoneInfo
import time

time.sleep(45)

print('running prox')

# Constants
MARGIN = 1
TRANSMIT = True
EST = ZoneInfo('US/Eastern')
ACCOUNT = "U5947157"
ADAPTIVE_PRIORITY = 'Urgent'
CONNECT_INFO = dict(host='127.0.0.1', port=7494, clientId=33)
CSV_PATH = "/home/user7496/Desktop/s2pro3/soxx_data.csv"  # Change this path to the location of your downloaded CSV file

# Function to read SOXX components from CSV
def read_soxx_components(csv_path):
    df = pd.read_csv(csv_path)
    soxx_components = df.set_index('Symbol')['Weight'].to_dict()
    total_weight = sum(soxx_components.values())
    soxx_components = {k: v / total_weight for k, v in soxx_components.items()}
    return soxx_components

# Include SOXX in the list of symbols to retrieve prices
SOXX_COMPONENTS = read_soxx_components(CSV_PATH)
ALL_SYMBOLS = list(SOXX_COMPONENTS.keys()) + ["SOXX"]

# Define async function to fetch historical data
async def get_data(symbols, ib):
    contracts = [ibi.Stock(symbol, 'SMART', 'USD') for symbol in symbols]
    await ib.qualifyContractsAsync(*contracts)
    bars = await asyncio.gather(*[ib.reqHistoricalDataAsync(contract, endDateTime='', durationStr='1 D',
                                                            barSizeSetting='1 day', whatToShow='Trades', useRTH=True) for contract in contracts])
    return {symbols[i]: float(bars[i][-1].close) if bars[i] else None for i in range(len(symbols))}

# Soxx Trading Class
class Soxx:

    async def trade(self):
        tradeTime = dt.datetime.now(EST)
        prepTime = tradeTime
        await self.waitUntil(prepTime)
        print('Preparing for trade...')

        self.ib = ibi.IB()
        with await self.ib.connectAsync(**CONNECT_INFO, account=ACCOUNT):
            contracts = {symbol: ibi.Stock(symbol, 'SMART', 'USD') for symbol in ALL_SYMBOLS}
            await self.ib.qualifyContractsAsync(*contracts.values())

            await self.waitUntil(tradeTime)

            # Fallback data retrieval methods
            prices = await self.get_prices_with_fallback(contracts)

            if any(price is None for price in prices.values()):
                print("Failed to retrieve prices using all methods.")
                return

            csv_path = "/home/user7496/Desktop/s2pro3/S2Proxdata.csv"
            df = pd.read_csv(csv_path, delimiter=",", header=None)
            soxx_price = prices['SOXX']
            prices_from_csv = df.iloc[:, 0].to_numpy()
            positions_from_csv = df.iloc[:, 1].to_numpy()
            rel_pos = 3*MARGIN*np.interp(soxx_price, prices_from_csv, positions_from_csv)
            print(f'SOXX: {soxx_price}\n rel.pos: {rel_pos}')

            accValue = self.getAccountValue()
            for symbol, contract in contracts.items():
                if symbol == "SOXX":
                    continue
                target_pos = rel_pos * SOXX_COMPONENTS[symbol]
                curr_pos = self.getQuantity(contract)
                price = prices[symbol]
                target_shares = target_pos * accValue / price
                shares_diff = target_shares - curr_pos

                trade_action = 'BUY' if shares_diff > 0 else 'SELL'
                qty = round(shares_diff) if trade_action == 'BUY' else round(shares_diff)
                if abs(qty) >= 1:  # Only trade if the quantity is at least 1
                    self.placeOrder(contract, qty, trade_action)
                else:
                    print('Less then 1')

    async def get_prices_with_fallback(self, contracts):
        prices = {symbol: self.ib.reqMktData(contract).marketPrice() for symbol, contract in contracts.items()}

        if any(self.read_failure(price) for price in prices.values()):
            prices = self.get_prices_from_yfinance(contracts.keys())

        if any(self.read_failure(price) for price in prices.values()):
            ib_prices = await get_data(list(contracts.keys()), self.ib)
            for symbol in prices:
                if self.read_failure(prices[symbol]):
                    prices[symbol] = ib_prices[symbol]

        return prices

    def get_prices_from_yfinance(self, symbols):
        prices = {}
        for symbol in symbols:
            tickerData = yf.Ticker(symbol)
            hist = tickerData.history(period='1d')
            current_price = hist['Close'].iloc[-1]
            prices[symbol] = float(current_price)
        return prices

    @staticmethod
    def read_failure(price):
        return price is None or np.isnan(price)

    def placeOrder(self, contract: ibi.Contract, qty: float, action: str) -> ibi.Trade:
        if abs(qty) < 1:
            print(f'Ignoring trade for {contract.symbol} due to quantity less than 1 (Qty: {qty})')
            return None

        print(f'Place {action} order for {abs(qty)} {contract.symbol}')
        order = ibi.MarketOrder(
            action=action,
            totalQuantity=abs(qty),
            algoStrategy='Adaptive',
            algoParams=[ibi.TagValue('adaptivePriority', ADAPTIVE_PRIORITY)],
            transmit=TRANSMIT,
            account=ACCOUNT)
        trade = self.ib.placeOrder(contract, order)
        return trade

    def getQuantity(self, contract: ibi.Contract) -> float:
        return next(
            (pos.position for pos in self.ib.positions(account=ACCOUNT)
             if pos.contract == contract), 0.0)

    def getAccountValue(self) -> float:
        av = next(
            v for v in self.ib.accountValues(account=ACCOUNT)
            if v.tag == 'NetLiquidation')
        return float(av.value)

    @staticmethod
    async def waitUntil(t: dt.datetime):
        now = dt.datetime.now(t.tzinfo)
        secs = (t - now).total_seconds()
        if secs > 0:
            await asyncio.sleep(secs)

    def run(self):
        try:
            asyncio.run(self.trade())
        except (KeyboardInterrupt, SystemExit):
            print('Program interrupted')

# Main Function
def main():
    ibi.util.logToFile('soxx.log')
    soxx = Soxx()
    soxx.run()

if __name__ == '__main__':
    main()

