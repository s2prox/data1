# download data
50 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_dl_soxx.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/dl_soxx.py >> /home/user7496/Desktop/s2pro3/output_dl_soxx.log 2>&1
55 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_dl.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/dl.py >> /home/user7496/Desktop/s2pro3/output_dl.log 2>&1



# stoploss_96
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_96_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk96_stoploss.py >> /home/user7496/Desktop/s2pro3/output_96_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_96_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk96_stoploss.py >> /home/user7496/Desktop/s2pro3/output_96_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_96_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk96_stoploss.py >> /home/user7496/Desktop/s2pro3/output_96_stoploss.log 2>&1
# daily rebalance_96
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_96.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk96_15.py >> /home/user7496/Desktop/s2pro3/output_96.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_96.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk96_30.py >> /home/user7496/Desktop/s2pro3/output_96.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_96.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk96_45.py >> /home/user7496/Desktop/s2pro3/output_96.log 2>&1



# stoploss_90
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_90_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk90_stoploss.py >> /home/user7496/Desktop/s2pro3/output_90_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_90_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk90_stoploss.py >> /home/user7496/Desktop/s2pro3/output_90_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_90_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk90_stoploss.py >> /home/user7496/Desktop/s2pro3/output_90_stoploss.log 2>&1
# daily rebalance_90
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_90.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk90_15.py >> /home/user7496/Desktop/s2pro3/output_90.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_90.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk90_30.py >> /home/user7496/Desktop/s2pro3/output_90.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_90.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk90_45.py >> /home/user7496/Desktop/s2pro3/output_90.log 2>&1


# stoploss_91
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_91_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk91_stoploss.py >> /home/user7496/Desktop/s2pro3/output_91_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_91_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk91_stoploss.py >> /home/user7496/Desktop/s2pro3/output_91_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_91_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk91_stoploss.py >> /home/user7496/Desktop/s2pro3/output_91_stoploss.log 2>&1
# daily rebalance_91
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_91.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk91_15.py >> /home/user7496/Desktop/s2pro3/output_91.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_91.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk91_30.py >> /home/user7496/Desktop/s2pro3/output_91.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_91.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk91_45.py >> /home/user7496/Desktop/s2pro3/output_91.log 2>&1


# stoploss_92
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_92_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk92_stoploss.py >> /home/user7496/Desktop/s2pro3/output_92_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_92_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk92_stoploss.py >> /home/user7496/Desktop/s2pro3/output_92_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_92_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk92_stoploss.py >> /home/user7496/Desktop/s2pro3/output_92_stoploss.log 2>&1
# daily rebalance_92
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_92.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk92_15.py >> /home/user7496/Desktop/s2pro3/output_92.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_92.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk92_30.py >> /home/user7496/Desktop/s2pro3/output_92.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_92.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk92_45.py >> /home/user7496/Desktop/s2pro3/output_92.log 2>&1




# stoploss_93
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_93_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk93_stoploss.py >> /home/user7496/Desktop/s2pro3/output_93_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_93_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk93_stoploss.py >> /home/user7496/Desktop/s2pro3/output_93_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_93_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk93_stoploss.py >> /home/user7496/Desktop/s2pro3/output_93_stoploss.log 2>&1
# daily rebalance_93
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_93.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk93_15.py >> /home/user7496/Desktop/s2pro3/output_93.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_93.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk93_30.py >> /home/user7496/Desktop/s2pro3/output_93.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_93.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk93_45.py >> /home/user7496/Desktop/s2pro3/output_93.log 2>&1



# stoploss_94
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_94_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk94_stoploss.py >> /home/user7496/Desktop/s2pro3/output_94_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_94_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk94_stoploss.py >> /home/user7496/Desktop/s2pro3/output_94_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_94_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk94_stoploss.py >> /home/user7496/Desktop/s2pro3/output_94_stoploss.log 2>&1
# daily rebalance_94
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_94.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk94_15.py >> /home/user7496/Desktop/s2pro3/output_94.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_94.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk94_30.py >> /home/user7496/Desktop/s2pro3/output_94.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_94.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk94_45.py >> /home/user7496/Desktop/s2pro3/output_94.log 2>&1



# stoploss_95
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_95_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk95_stoploss.py >> /home/user7496/Desktop/s2pro3/output_95_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_95_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk95_stoploss.py >> /home/user7496/Desktop/s2pro3/output_95_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_95_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk95_stoploss.py >> /home/user7496/Desktop/s2pro3/output_95_stoploss.log 2>&1
# daily rebalance_95
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_95.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk95_15.py >> /home/user7496/Desktop/s2pro3/output_95.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_95.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk95_30.py >> /home/user7496/Desktop/s2pro3/output_95.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_95.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk95_45.py >> /home/user7496/Desktop/s2pro3/output_95.log 2>&1


# stoploss_97
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_97_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk97_stoploss.py >> /home/user7496/Desktop/s2pro3/output_97_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_97_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk97_stoploss.py >> /home/user7496/Desktop/s2pro3/output_97_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_97_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk97_stoploss.py >> /home/user7496/Desktop/s2pro3/output_97_stoploss.log 2>&1
# daily rebalance_97
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_97.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk97_15.py >> /home/user7496/Desktop/s2pro3/output_97.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_97.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk97_30.py >> /home/user7496/Desktop/s2pro3/output_97.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_97.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk97_45.py >> /home/user7496/Desktop/s2pro3/output_97.log 2>&1



# stoploss_98
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_98_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk98_stoploss.py >> /home/user7496/Desktop/s2pro3/output_98_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_98_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk98_stoploss.py >> /home/user7496/Desktop/s2pro3/output_98_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_98_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk98_stoploss.py >> /home/user7496/Desktop/s2pro3/output_98_stoploss.log 2>&1
# daily rebalance_98
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_98.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk98_15.py >> /home/user7496/Desktop/s2pro3/output_98.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_98.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk98_30.py >> /home/user7496/Desktop/s2pro3/output_98.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_98.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk98_45.py >> /home/user7496/Desktop/s2pro3/output_98.log 2>&1



# stoploss_99
31-59 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_99_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk99_stoploss.py >> /home/user7496/Desktop/s2pro3/output_99_stoploss.log 2>&1
* 10-14 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_99_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk99_stoploss.py >> /home/user7496/Desktop/s2pro3/output_99_stoploss.log 2>&1
0-57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_99_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk99_stoploss.py >> /home/user7496/Desktop/s2pro3/output_99_stoploss.log 2>&1
# daily rebalance_99
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_99.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk99_15.py >> /home/user7496/Desktop/s2pro3/output_99.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_99.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk99_30.py >> /home/user7496/Desktop/s2pro3/output_99.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_99.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/stk99_45.py >> /home/user7496/Desktop/s2pro3/output_99.log 2>&1

