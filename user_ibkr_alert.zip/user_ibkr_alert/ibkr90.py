#!/home/user7496/Desktop/s2pro3/ib_ven/bin/python3
import sys
import io
import requests
import json
import ibkr_alert90   
import time


# 捕获输出的函数
def capture_output():
    captured_output = io.StringIO()
    sys.stdout = captured_output
    return captured_output

# 发送到Discord的函数
def send_message_to_discord(message):
    DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/1267955010117959832/fm8wJospnTq8DsoeYkRWLJ8AGK5Nx3jle03tVgrkHxjj2_4QrJzCxZmKF1ylXoO70-9k'  
    data = {"content": message, "username": "Python Output Bot"}
    response = requests.post(DISCORD_WEBHOOK_URL, json.dumps(data), headers={"Content-Type": "application/json"})
    if response.status_code == 204:
        print("消息成功发送到Discord!")
    else:
        print(f"发送失败，错误码: {response.status_code}")

# 主函数
def main():
    # 开始捕获输出
    captured_output = capture_output()

    # 运行 pos.py 的内容
    try:
        ibkr_alert90.main()# 如果 pos.py 中有一个名为 run 或 main 的函数，可以调用它
        # 例如：pos.run() 或 pos.main()
        # 如果 pos.py 直接运行代码（没有封装在函数内），则不需要调用
        pass
    except Exception as e:
        print(f"运行错误: {e}")

    # 恢复标准输出
    sys.stdout = sys.__stdout__

    # 获取并发送输出
    output = captured_output.getvalue()
    send_message_to_discord(output)

if __name__ == '__main__':
    main()