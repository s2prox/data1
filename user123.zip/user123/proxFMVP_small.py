import subprocess
print('runing prox...')

def run_script(script_name):
    try:
        subprocess.check_call(['/home/user123/Desktop/s2pro3/' + script_name])
        return True 
    except subprocess.CalledProcessError:
        return False

if __name__ == "__main__":
    if not run_script('prox_test_small.py'):
        for i in range(3):  # Try to run 'prox_test.py' up to 3 times
            if run_script('prox_test_small1.py'):
                break  # If 'prox_now.py' runs successfully, exit the loop