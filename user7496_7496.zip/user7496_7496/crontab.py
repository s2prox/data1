#prox_stoploss_96
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox96_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox96_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox96_stoploss.log 2>&1
# download all the data_5
55 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_dl.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/dl.py >> /home/user7496/Desktop/s2pro3/output_dl.log 2>&1
# prox_rebalance_triger_gcp
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox96_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox96_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox96_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox96_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox96_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox96_now.log 2>&1



#prox_stoploss_97
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox97_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox97_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox97_stoploss.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox97_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox97_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox97_now.log 2>&1



##prox_stoploss_98
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox98_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox98_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox98_stoploss.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox98_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox98_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox98_now.log 2>&1



##prox_stoploss_99
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox99_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox99_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox99_stoploss.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox99_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox99_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox99_now.log 2>&1



##prox_stoploss_90
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox90_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox90_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox90_stoploss.log 2>&1

59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox90_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox90_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox90_now.log 2>&1



#prox_stoploss_91
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox91_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox91_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox91_stoploss.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox91_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox91_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox91_now.log 2>&1



##prox_stoploss_92
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox92_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox92_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox92_stoploss.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox92_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox92_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox92_now.log 2>&1



##prox_stoploss_93
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox93_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox93_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox93_stoploss.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox93_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox93_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox93_now.log 2>&1



#prox_stoploss_94
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox94_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox94_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox94_stoploss.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox94_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox94_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox94_now.log 2>&1



#prox_stoploss_95
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox95_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox95_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox95_stoploss.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox95_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox95_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox95_now.log 2>&1



