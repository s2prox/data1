import os
import shutil

def replace_text_in_file(file_path, replacements):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # First replace all occurrences of the old number with a placeholder
    placeholder = "7498"
    content = content.replace(replacements[1][0], placeholder)

    # Now perform all replacements
    for old_text, new_text in replacements:
        content = content.replace(old_text, new_text)

    # Finally, replace the placeholder with the new number
    content = content.replace(placeholder, replacements[1][1])

    return content

def main():
    base_dir = "/Users/alanyang/Dropbox/crontab_all_4"
    destination_dir = "/Users/alanyang/Dropbox/members"  # New destination directory
    
    for i in range(5):
        user_old = "user7498"
        user_new = f"user{7498 + i}"
        number_old = "7498"
        number_new = f"{7498 + i}"
        replacements = [(user_old, user_new), (number_old, number_new)]

        new_dir_name = "_".join([pair[1] for pair in replacements])
        new_dir = os.path.join(destination_dir, new_dir_name)  # Adjusted to new destination

        if not os.path.exists(new_dir):
            os.makedirs(new_dir)

        for root, dirs, files in os.walk(base_dir):
            if new_dir_name in dirs:
                dirs.remove(new_dir_name)
            
            for file in files:
                file_path = os.path.join(root, file)
                new_file_path = os.path.join(new_dir, file)
                
                if file.endswith('.py'):
                    updated_content = replace_text_in_file(file_path, replacements)
                    
                    with open(new_file_path, 'w', encoding='utf-8') as f:
                        f.write(updated_content)
                else:
                    shutil.copy(file_path, new_file_path)

if __name__ == "__main__":
    main()
