#!/home/user7498/Desktop/s2pro3/ib_ven/bin/python3
import asyncio
import datetime as dt
from typing import List
import time
from zoneinfo import ZoneInfo
import math
import ib_insync as ibi
import numpy as np
import pandas as pd  
import yfinance as yf
print('running prox')
# xiaowen
MARGIN = 0.95
TRANSMIT = True
time.sleep(36)

# Define async function to fetch historical data
async def get_data(symbols, ib):
    contract = ibi.Stock(symbols, 'SMART', 'USD')
    await ib.qualifyContractsAsync(contract)
    bars = await ib.reqHistoricalDataAsync(contract, endDateTime='', durationStr='1 D',
                                           barSizeSetting='1 day', whatToShow='Trades', useRTH=True)
    return {symbols: float(bars[-1].close) if bars else None}

# Define async function to initialize the connection and fetch the prices
async def main(tickers):
    ib = ibi.IB()
    await ib.connectAsync('127.0.0.1', 7498, clientId=11)
    tasks = [get_data(ticker, ib) for ticker in tickers]
    prices = await asyncio.gather(*tasks)
    ib.disconnect()
    return prices

# Fetch the last price for each ticker simultaneously
tickers = ['SOXX', 'SOXL', 'SOXS']
prices = asyncio.run(main(tickers))

PPrice = float(prices[0]['SOXX']) if float(prices[0]['SOXX']) else None
PPrice1 = float(prices[1]['SOXL']) if float(prices[1]['SOXL']) else None
PPrice2 = float(prices[2]['SOXS']) if float(prices[2]['SOXS']) else None


CONNECT_INFO = dict(host='127.0.0.1', port=7498, clientId= 51)





# Imac use host='10.131.58.247',  others use host='127.0.0.1'

"""IB connection info."""

ADAPTIVE_PRIORITY = 'Urgent'
"""How long to wait for filling orders: 'Urgent', 'Normal' or 'Patient'."""

STRATEGY = "prox"

"""Strategy to Filename of input CSV mapping"""
STRATEGY_TYPE = {
    "pro3": "S2Pro3data.csv",
    "prox": "S2Proxdata.csv",
    "pro7": "S2Pro7data.csv",
}

LOSS_PERC = 5.5

EST = ZoneInfo('US/Eastern')
"""Time to evaluate and initiate the trade."""

"""Default account"""

ACCOUNT = "U11356429"

"""System to trade SOXX at the end of the day."""
class Soxx:

    async def trade(self):
        tradeTime = dt.datetime.now(EST)  
        prepTime = tradeTime  
        # Wait until time to prepare is reached.
        print('Running...')
        await self.waitUntil(prepTime)
        print('Preparing for trade...')

        self.ib = ibi.IB()
        with await self.ib.connectAsync(**CONNECT_INFO, account=ACCOUNT):
            # Create contracts.
            self.soxx = ibi.Stock('SOXX', 'SMART', 'USD')
            self.soxl = ibi.Stock('SOXL', 'SMART', 'USD')
            self.soxs = ibi.Stock('SOXS', 'SMART', 'USD')
            await self.ib.qualifyContractsAsync(self.soxx, self.soxl, self.soxs)

            # Subscribe to SOXX market data.
            soxxTicker = self.ib.reqMktData(self.soxx)
            soxlTicker = self.ib.reqMktData(self.soxl)
            soxsTicker = self.ib.reqMktData(self.soxs)

            # Wait until trading time.
            await self.waitUntil(tradeTime)
            # self.cancel_stop_orders()


            @staticmethod
            def isnoneornan(price):
                if price is None or np.isnan(price):
                    return True
                else:
                    return False

            @staticmethod 
            def read_failure(price, price1, price2):
                # if failure return True 
                if isnoneornan(price) or isnoneornan(price1) or isnoneornan(price2):
                    return True 
                else:
                    return False 

            maxiters = 5
            ii=0
            price = self.ib.reqMktData(self.soxx).marketPrice()
            price1 = self.ib.reqMktData(self.soxl).marketPrice()
            price2 = self.ib.reqMktData(self.soxs).marketPrice()

            print(price)

            while read_failure(price,price1,price2) and ii< maxiters:
                time.sleep(0.2)
                price = self.ib.reqMktData(self.soxx).marketPrice()
                price1 = self.ib.reqMktData(self.soxl).marketPrice()
                price2 = self.ib.reqMktData(self.soxs).marketPrice()
                # update the iteration index 
                ii += 1 
                print(ii)

            if read_failure(price,price1,price2):
                # use yahoo finance API to get the prices
                symbols = ["SOXX", "SOXL", "SOXS"]
                prices = self.get_prices(symbols)
                price = prices['SOXX']
                price1 = prices['SOXL']
                price2 = prices['SOXS']
                print(f"SOXX Price2 from yfinance = {price}")

            if read_failure(price,price1,price2):
                # use yahoo finance API to get the prices
                price = PPrice
                price1 = PPrice1
                price2 = PPrice2
                print(f"SOXX Price1 from IBKR = {price}")

            csv_path = "/home/user7498/Desktop/s2pro3/S2Proxdata.csv"

            # Find desired overall postition.
            df = pd.read_csv(csv_path, delimiter=",", header=None)
            prices = df.iloc[:, 0].to_numpy()
            positions = df.iloc[:, 1].to_numpy()
            rel_pos = np.interp(price, prices, positions)
            print(f' SOXX: {price}\n SOXL: {price1}\n SOXS: {price2}\n rel.pos: {rel_pos}')

            # Calculate quantities to trade to reach desired overall position,
            # using SOXL for a long and SOXS for a short position.
            curr_soxl_pos = self.getQuantity(self.soxl)
            curr_soxs_pos = self.getQuantity(self.soxs)
            accValue = self.getAccountValue()
            if rel_pos > 0:
                new_soxl_pos = rel_pos * accValue / price1
                new_soxs_pos = 0
            else:
                new_soxl_pos = 0
                new_soxs_pos = -rel_pos * accValue / price2

            soxl_qty = math.ceil(MARGIN*new_soxl_pos - curr_soxl_pos)
            soxs_qty = math.ceil(MARGIN*new_soxs_pos - curr_soxs_pos)

            # Place orders.
            trades: List[ibi.Trade] = []
            if soxl_qty <= soxs_qty:
                trade = self.placeOrder(self.soxl, soxl_qty)
                trades += [trade]
                time.sleep(5)
                trade = self.placeOrder(self.soxs, soxs_qty)
                trades += [trade]
            else:
                trade = self.placeOrder(self.soxs, soxs_qty)
                trades += [trade]
                time.sleep(5)
                trade = self.placeOrder(self.soxl, soxl_qty)
                trades += [trade]
            # Wait until orders are filled.
            async for _ in self.ib.updateEvent:
                if all(trade.isDone() for trade in trades):
                    for trade in trades:
                        print(f'Filled {trade.filled()} '
                              f'{trade.contract.symbol} @ '
                              f'{trade.orderStatus.avgFillPrice}')
                break

    def get_prices(self, symbols):
        prices = {}
        for symbol in symbols:
            # Get data on this ticker
            tickerData = yf.Ticker(symbol)
            # Get historical prices for the last day
            hist = tickerData.history(period='1d')
            # Get the last closing price
            current_price = hist['Close'].iloc[0]
            # Add to dictionary
            prices[symbol] = float(current_price)

        return prices

    def placeOrder(self, contract: ibi.Contract, qty: float) -> ibi.Trade:
        print(f'Place order for {qty} {contract.symbol}')
        order = ibi.MarketOrder(
            action='BUY' if qty > 0 else 'SELL',
            totalQuantity=abs(qty),
            # algoStrategy='Adaptive',
            # algoParams=[ibi.TagValue('adaptivePriority', ADAPTIVE_PRIORITY)],
            transmit=TRANSMIT,
            account=ACCOUNT)
        trade = self.ib.placeOrder(contract, order)
        return trade

    def cancel_stop_orders(self):
        """Cancel all old stop orders."""
        for order in self.ib.openOrders():
            if order.orderType == "STP" or order.orderType == "STP LMT":
                self.ib.cancelOrder(order)


    def getQuantity(self, contract: ibi.Contract) -> float:
        """Return current holding quantity of the contract."""
        return next((
            pos.position for pos in self.ib.positions(account=ACCOUNT)
            if pos.contract == contract), 0.0)

    def getAccountValue(self) -> float:
        """Net worth of the account."""
        av = next(
            v for v in self.ib.accountValues(account=ACCOUNT)
            if v.tag == 'NetLiquidation')
        return float(av.value)

    @staticmethod
    async def waitUntil(t: dt.datetime):
        now = dt.datetime.now(t.tzinfo)
        secs = (t - now).total_seconds()
        if secs > 0:
            await asyncio.sleep(secs)

    def run(self):
        try:
            asyncio.run(self.trade())
        except (KeyboardInterrupt, SystemExit):
            print('Program interrupted')

def main():
    ibi.util.logToFile('soxx.log')
    soxx = Soxx()
    soxx.run()


if __name__ == '__main__':
    main()