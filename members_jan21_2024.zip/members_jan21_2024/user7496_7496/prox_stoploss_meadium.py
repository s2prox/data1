#!/home/user7496/Desktop/s2pro3/ib_ven/bin/python3
import logging
from ib_insync import IB, Stock, StopLimitOrder, util
from datetime import datetime, timedelta
import time
import pytz
import yfinance as yf

logging.basicConfig(level=logging.ERROR)


def is_market_open():
    now = datetime.now(pytz.timezone('US/Eastern'))
    market_open_time = now.replace(hour=9, minute=30, second=0, microsecond=0)
    market_close_time = now.replace(hour=16, minute=0, second=0, microsecond=0)
    if now.weekday() < 5 and market_open_time <= now <= market_close_time:
        return True
    else:
        return False

def get_recent_close_price_and_open_price(contracts, market_open):
    now = datetime.now(pytz.timezone('US/Eastern'))
    end_date = now.strftime('%Y%m%d %H:%M:%S')
    price_data = {}

    for contract in contracts:
        daily_bars = ib.reqHistoricalData(
            contract,
            endDateTime=end_date,
            durationStr='2 D',
            barSizeSetting='1 day',
            whatToShow='TRADES',
            useRTH=True,
            formatDate=1
        )

        if daily_bars:
            close_price = daily_bars[-2].close  # Get yesterday's close price
        else:
            return None, None

        if market_open:
            ticker = ib.reqMktData(contract, '100')  # Request real-time data
            ib.sleep(1)  # Wait for the data to be received
            open_price = ticker.open
            # ib.cancelMktData(ticker)  # Cancel the real-time data subscription
        else:
            open_price = None

        price_data[contract.symbol] = {
            'close_price': close_price,
            'open_price': open_price
        }

    return price_data

def get_prices(symbols):
    prices = {}
    for symbol in symbols:
        tickerData = yf.Ticker(symbol)
        hist = tickerData.history(period='2d')
        if is_market_open():  # If before market open (assuming Eastern Time)
            current_price = hist['Close'].iloc[0]  # Get yesterday's close price
        else:
            current_price = hist['Close'].iloc[-1]  # Get the day before yesterday's close price
        prices[symbol] = float(current_price)
    return prices


transmit_order = True
target_account = 'U9005581'

ib = IB()
ib.connect('127.0.0.1', 7496, clientId= 8)


print('Connected to ibkr...\n')

soxl = Stock('SOXL', 'SMART', 'USD')
soxs = Stock('SOXS', 'SMART', 'USD')
soxx = Stock('SOXX', 'SMART', 'USD')

soxl_contract = ib.qualifyContracts(soxl)[0]
soxs_contract = ib.qualifyContracts(soxs)[0]
soxx_contract = ib.qualifyContracts(soxx)[0]

positions = ib.positions()
target_stock = None
position_size = 0



for position in positions:
    if position.contract == soxl_contract and position.account == target_account:
        target_stock = soxl_contract
        position_size = abs(position.position)
        break
    elif position.contract == soxs_contract and position.account == target_account:
        target_stock = soxs_contract
        position_size = abs(position.position)
        break

if target_stock is None:
    print(f"No SOXL or SOXS positions found in the account: {target_account}.")
    ib.disconnect()
    exit()

market_open = is_market_open()
price_data = get_recent_close_price_and_open_price([soxl_contract, soxx_contract], market_open)
price_data1 = get_recent_close_price_and_open_price([soxs_contract, soxx_contract], market_open)


symbols = ["SOXX", "SOXL", "SOXS"]
prices = get_prices(symbols)

soxl_close_price = prices['SOXL']
soxx_close_price = prices['SOXX']
soxs_close_price = prices['SOXS'] 
soxx_open_price = price_data['SOXX']['open_price']


print('soxs_close = ' + str(soxs_close_price)+ "\n")
print('soxx_close = ' + str(soxx_close_price)+ "\n")
print('soxl_close = ' + str(soxl_close_price)+ "\n")
print('soxx_open = ' + str(soxx_open_price)+ "\n")


open_rate = 3*(soxx_open_price/soxx_close_price-1)/2

print('open_rate = ' + str(open_rate)+ "\n")


if soxx_open_price is not None and soxx_close_price is not None:
    soxx_price_change = (soxx_open_price / soxx_close_price - 1) * 3
else:
    print("Error: Missing price data for SOXX.")
    ib.disconnect()
    exit()

if target_stock.localSymbol =='SOXL':
    place_stoploss_order = True
    if soxx_open_price is not None:
        if soxx_price_change > 0.05:
            stop_price = soxl_close_price * 0.9
        elif 0.0296 <= soxx_price_change <= 0.05:
            stop_price = soxl_close_price * 1.0296
        elif 0.00064 <= soxx_price_change < 0.0296:
            stop_price = soxl_close_price * (1 + open_rate) 
        elif -0.055 <= soxx_price_change < 0:
            stop_price = soxl_close_price * 0.945
        else:
            place_stoploss_order = False

    else:
        stop_price = soxl_close_price
elif target_stock.localSymbol == 'SOXS' and soxx_price_change < 0.33/100:
    place_stoploss_order = False
    stop_price = soxs_close_price *0.99


stop_price = round(stop_price,2)

if place_stoploss_order:
    stop_limit_order = StopLimitOrder(
        action='SELL',
        totalQuantity=position_size,
        stopPrice=stop_price,
        lmtPrice=stop_price,
    )
    stop_limit_order.transmit = transmit_order
    stop_limit_order.account = target_account

    trade = ib.placeOrder(target_stock, stop_limit_order)
    print(f"Stop loss order submitted for {target_stock.localSymbol} at price {stop_price}")
else:
    print(f"No stop loss order placed for {target_stock.localSymbol} due to the open price condition.")

ib.sleep(35)  # Add a sleep statement here
ib.disconnect()