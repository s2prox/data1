#!/home/user7496/Desktop/s2pro3/ib_ven/bin/python3
import logging
import subprocess
from ib_insync import IB, Stock, util
from datetime import datetime
import pytz
import yfinance as yf
import numpy as np
import pandas as pd

logging.basicConfig(level=logging.ERROR)

def is_market_open():
    now = datetime.now(pytz.timezone('US/Eastern'))
    market_open_time = now.replace(hour=9, minute=30, second=0, microsecond=0)
    market_close_time = now.replace(hour=16, minute=0, second=0, microsecond=0)
    return now.weekday() < 5 and market_open_time <= now <= market_close_time

def get_prices(symbols):
    prices = {}
    for symbol in symbols:
        tickerData = yf.Ticker(symbol)
        hist = tickerData.history(period='2d')
        current_price = hist['Close'].iloc[-2]  # Get yesterday's close price
        prices[symbol] = float(current_price)
    return prices

def get_open_price_from_ib(ib, contract):
    ticker = ib.reqMktData(contract, '100')  # Request real-time data
    ib.sleep(1)  # Wait for the data to be received
    open_price = ticker.open
    ib.cancelMktData(contract)  # Cancel the real-time data subscription

    return open_price

def get_intraday_low_price_from_ib(ib, contract):
    now = datetime.now(pytz.timezone('US/Eastern'))
    end_date = now.strftime('%Y%m%d %H:%M:%S')
    
    # Request historical data for the current day with 1-minute bars
    bars = ib.reqHistoricalData(
        contract,
        endDateTime=end_date,
        durationStr='1 D',
        barSizeSetting='1 min',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1
    )

    # Extract the low prices from the bars and find the minimum
    low_prices = [bar.low for bar in bars]
    min_price = min(low_prices) if low_prices else None

    return min_price
    
    
    
def get_position(ib, contract):
    positions = ib.positions()
    for position in positions:
        if position.contract.conId == contract.conId:
            return position.position
    return 0    
    


# Variables
transmit_order = True
target_account = 'U5947157'

# Connect to IB
ib = IB()
ib.connect('127.0.0.1', 7493, clientId=34)
print('Connected to ibkr...\n')

# Define the contracts
soxx = Stock('SOXX', 'SMART', 'USD')

# Qualify contracts
soxx_contract = ib.qualifyContracts(soxx)[0]

# Get close and open prices
symbols = ["SOXX"]
prices = get_prices(symbols)

soxx_close_price = prices['SOXX']
soxx_open_price = get_open_price_from_ib(ib, soxx_contract)
soxx_intraday_low_price = get_intraday_low_price_from_ib(ib, soxx_contract)

print('soxx_close = ' + str(soxx_close_price) + "\n")
print('soxx_open = ' + str(soxx_open_price) + "\n")
print('soxx_intraday_low = ' + str(soxx_intraday_low_price) + "\n")

open_rate =  (soxx_open_price / soxx_close_price - 1)
print('open_rate = ' + str(open_rate) + "\n")

soxx_price_change = (soxx_open_price / soxx_close_price - 1)

if 0.0296/3 <= soxx_price_change <= 0.05/3:
    stop_price = soxx_close_price * (1+0.0296 / 3)
elif 0.0 <= soxx_price_change < 0.0296/3:
    stop_price = soxx_close_price * (1 + open_rate/2)
elif -0.055/3 <= soxx_price_change < 0:
    stop_price = soxx_close_price * (1 - 5.5 / 100 / 3)
else:
    stop_price = soxx_close_price * 0.5

stop_price = round(stop_price, 2)
print(f"Calculated stop_price: {stop_price}")

# Monitor SOXX price and trigger stoploss.py if conditions are met


csv_path = "/home/user7496/Desktop/s2pro3/S2Proxdata.csv"
df = pd.read_csv(csv_path, delimiter=",", header=None)
soxx_price = soxx_close_price
prices_from_csv = df.iloc[:, 0].to_numpy()
positions_from_csv = df.iloc[:, 1].to_numpy()
rel_pos = 3*np.interp(soxx_price, prices_from_csv, positions_from_csv)
print(f'SOXX: {soxx_price}\n rel.pos: {rel_pos}')

rel_1 = 1 if rel_pos > 0 else 0


current_intraday_low = get_intraday_low_price_from_ib(ib, soxx_contract)
print(f"Current intraday low: {current_intraday_low}")
if rel_1 and current_intraday_low and current_intraday_low < stop_price:
    print("Stop-loss condition met. Running stoploss.py...")
    subprocess.run(["/home/user7496/Desktop/s2pro3/stk93_0.py"])
else:
    print('SOXX is still not triggered')

print('---End of the code ----\n\n')

ib.disconnect()
