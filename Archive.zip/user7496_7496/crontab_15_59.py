#prox_stoploss_96
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox96_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox96_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox96_stoploss.log 2>&1
55 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_dl.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/dl.py >> /home/user7496/Desktop/s2pro3/output_dl.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox96_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox96_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox96_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox96_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox96_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox96_now.log 2>&1



#prox_stoploss_90
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox90_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox90_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox90_stoploss.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox90_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox90_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox90_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox90_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox90_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox90_now.log 2>&1



#prox_stoploss_91
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox91_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox91_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox91_stoploss.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox91_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox91_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox91_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox91_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox91_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox91_now.log 2>&1



##prox_stoploss_92
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox92_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox92_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox92_stoploss.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox92_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox92_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox92_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox92_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox92_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox92_now.log 2>&1



##prox_stoploss_93
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox93_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox93_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox93_stoploss.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox93_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox93_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox93_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox93_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox93_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox93_now.log 2>&1



#prox_stoploss_94
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox94_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox94_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox94_stoploss.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox94_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox94_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox94_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox94_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox94_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox94_now.log 2>&1



#prox_stoploss_95
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox95_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox95_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox95_stoploss.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox95_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox95_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox95_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox95_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox95_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox95_now.log 2>&1



#prox_stoploss_97
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox97_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox97_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox97_stoploss.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox97_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox97_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox97_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox97_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox97_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox97_now.log 2>&1



##prox_stoploss_98
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox98_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox98_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox98_stoploss.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox98_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox98_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox98_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox98_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox98_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox98_now.log 2>&1



##prox_stoploss_99
31 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox99_stoploss.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox99_stoplossFMVP.py >> /home/user7496/Desktop/s2pro3/output_prox99_stoploss.log 2>&1
57 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox99_triger.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox99_FMVP2.py >> /home/user7496/Desktop/s2pro3/output_prox99_triger.log 2>&1
59 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_prox99_now.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/prox99_FMVP.py >> /home/user7496/Desktop/s2pro3/output_prox99_now.log 2>&1




26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr90.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr90.py >> /home/user7496/Desktop/s2pro3/output_ibkr90.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr90.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr90.py >> /home/user7496/Desktop/s2pro3/output_ibkr90.log 2>&1

26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr91.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr91.py >> /home/user7496/Desktop/s2pro3/output_ibkr91.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr91.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr91.py >> /home/user7496/Desktop/s2pro3/output_ibkr91.log 2>&1

26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr92.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr92.py >> /home/user7496/Desktop/s2pro3/output_ibkr92.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr92.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr92.py >> /home/user7496/Desktop/s2pro3/output_ibkr92.log 2>&1

26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr93.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr93.py >> /home/user7496/Desktop/s2pro3/output_ibkr93.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr93.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr93.py >> /home/user7496/Desktop/s2pro3/output_ibkr93.log 2>&1

26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr94.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr94.py >> /home/user7496/Desktop/s2pro3/output_ibkr94.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr94.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr94.py >> /home/user7496/Desktop/s2pro3/output_ibkr94.log 2>&1

26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr95.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr95.py >> /home/user7496/Desktop/s2pro3/output_ibkr95.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr95.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr95.py >> /home/user7496/Desktop/s2pro3/output_ibkr95.log 2>&1

26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr96.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr96.py >> /home/user7496/Desktop/s2pro3/output_ibkr96.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr96.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr96.py >> /home/user7496/Desktop/s2pro3/output_ibkr96.log 2>&1

26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr97.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr97.py >> /home/user7496/Desktop/s2pro3/output_ibkr97.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr97.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr97.py >> /home/user7496/Desktop/s2pro3/output_ibkr97.log 2>&1


26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr98.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr98.py >> /home/user7496/Desktop/s2pro3/output_ibkr98.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr98.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr98.py >> /home/user7496/Desktop/s2pro3/output_ibkr98.log 2>&1

26 9 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr99.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr99.py >> /home/user7496/Desktop/s2pro3/output_ibkr99.log 2>&1
56 15 * * 1-5 echo "$(date)" >> /home/user7496/Desktop/s2pro3/output_ibkr99.log 2>&1 && /home/user7496/Desktop/s2pro3/ib_ven/bin/python /home/user7496/Desktop/s2pro3/ibkr99.py >> /home/user7496/Desktop/s2pro3/output_ibkr99.log 2>&1















