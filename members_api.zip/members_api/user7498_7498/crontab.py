#prox_stoploss_1
31 9 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_prox_stoploss.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/prox_stoplossFMVP.py >> /home/user7498/Desktop/s2pro3/output_prox_stoploss.log 2>&1

# download all the data_5
55 15 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_dl.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/dl.py >> /home/user7498/Desktop/s2pro3/output_dl.log 2>&1

# prox_rebalance_triger_gcp
57 15 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_prox_triger.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/proxFMVP2.py >> /home/user7498/Desktop/s2pro3/output_prox_triger.log 2>&1

# prox_rebalance_1
59 15 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_prox_now.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/proxFMVP.py >> /home/user7498/Desktop/s2pro3/output_prox_now.log 2>&1





#prox_stoploss_2
31 9 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_prox_stoploss_big.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/prox_stoplossFMVP_big.py >> /home/user7498/Desktop/s2pro3/output_prox_stoploss_big.log 2>&1

# prox_rebalance_2
59 15 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_prox_now_big.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/proxFMVP_big.py >> /home/user7498/Desktop/s2pro3/output_prox_now_big.log 2>&1





#prox_stoploss_meadium_3
31 9 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_prox_stoploss_meadium.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/prox_stoplossFMVP_meadium.py >> /home/user7498/Desktop/s2pro3/output_prox_stoploss_meadium.log 2>&1

# prox_rebalance_meadium_3
59 15 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_prox_now_meadium.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/proxFMVP_meadium.py >> /home/user7498/Desktop/s2pro3/output_prox_now_meadium.log 2>&1





#prox_stoploss_4
31 9 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_prox_stoploss_small.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/prox_stoplossFMVP_small.py >> /home/user7498/Desktop/s2pro3/output_prox_stoploss_small.log 2>&1

# prox_rebalance_4
59 15 * * 1-5 echo "$(date)" >> /home/user7498/Desktop/s2pro3/output_prox_now_small.log 2>&1 && /home/user7498/Desktop/s2pro3/ib_ven/bin/python /home/user7498/Desktop/s2pro3/proxFMVP_small.py >> /home/user7498/Desktop/s2pro3/output_prox_now_small.log 2>&1
